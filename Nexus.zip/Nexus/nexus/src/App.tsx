import { useState } from "react";
import Sidebar from "./components/Sidebar";
import ChatArea from "./components/ChatArea";
import AuthLanding from "./components/AuthLanding";
import type { Workspace, Channel, Message } from "./types";

const INITIAL_WORKSPACES: Workspace[] = [
  {
    id: "nexus",
    name: "Nexus",
    icon: "N",
    colorClass: "purple",
    channels: [
      { id: "general", name: "General", description: "Company-wide announcements and work-based matters", memberCount: 24 },
      { id: "development", name: "Development", description: "Development Team • Standups & Code Reviews", memberCount: 12 },
      { id: "design", name: "Design", description: "UI/UX updates, design system & review feedback", memberCount: 8 },
      { id: "marketing", name: "Marketing", description: "Campaigns, growth strategy & social media", memberCount: 15 },
    ],
  },
  {
    id: "bleuoise",
    name: "Bleüoise",
    icon: "B",
    colorClass: "blue",
    channels: [
      { id: "b-general", name: "General", description: "Bleüoise main workspace discussion", memberCount: 18 },
      { id: "b-client-ops", name: "Client Ops", description: "Client delivery and updates", memberCount: 9 },
    ],
  },
  {
    id: "wakajeje",
    name: "Wakajeje",
    icon: "W",
    colorClass: "orange",
    channels: [
      { id: "w-general", name: "General", description: "Wakajeje community and events", memberCount: 30 },
      { id: "w-events", name: "Events", description: "Planning regional meetups", memberCount: 14 },
    ],
  },
];

const INITIAL_MESSAGES: Record<string, Message[]> = {
  general: [
    {
      id: "gen-1",
      sender: { id: "user-1", name: "Sarah", avatar: "S", status: "online" },
      text: "Welcome everyone to the General channel!",
      time: "8:30 AM",
      reactions: ["👋"],
    },
  ],
  development: [
    {
      id: "dev-1",
      sender: { id: "user-1", name: "Sarah", avatar: "S", status: "online" },
      text: "Hey everyone 👋 Welcome to the Development channel where we have our daily standup!",
      time: "9:12 AM",
      reactions: ["👋"],
    },
    {
      id: "dev-2",
      sender: { id: "user-2", name: "Alexander", avatar: "A", status: "online" },
      text: "The new dashboard is ready. I would love to get everyone's feedback.",
      time: "9:18 AM",
      reactions: ["🚀"],
    },
    {
      id: "dev-3",
      sender: { id: "user-3", name: "David", avatar: "D", status: "away" },
      text: "Looks great 🔥 The navigation is really clean.",
      time: "9:21 AM",
      reactions: ["🔥"],
    },
  ],
  design: [
    {
      id: "des-1",
      sender: { id: "user-4", name: "Elena", avatar: "E", status: "online" },
      text: "Fada Said we need to come up with new designs b4 friday!",
      time: "10:05 AM",
      reactions: ["✨"],
    },
  ],
  marketing: [
    {
      id: "mkt-1",
      sender: { id: "user-5", name: "Marcus", avatar: "M", status: "offline" },
      text: "We need to communicate concerning this our current marketing strategy today guys 🎉",
      time: "11:00 AM",
      reactions: ["🎉"],
    },
  ],
  "b-general": [
    {
      id: "bg-1",
      sender: { id: "user-2", name: "Alexander", avatar: "A", status: "online" },
      text: "Welcome to Bleüoise workspace! kindly drop your costume Ideas b4 the next fashion week",
      time: "1:00 PM",
      reactions: ["💙"],
    },
  ],
  "w-general": [
    {
      id: "wg-1",
      sender: { id: "user-3", name: "David", avatar: "D", status: "away" },
      text: "Wakajeje workspace is now live, Pls contact Fada for the of stand up.",
      time: "2:15 PM",
      reactions: ["🟠"],
    },
  ],
};

function App() {
  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState("Alexander");

  // App workspace states
  const [workspaces, setWorkspaces] = useState<Workspace[]>(INITIAL_WORKSPACES);
  const [activeWorkspaceId, setActiveWorkspaceId] = useState<string>("nexus");
  const [activeChannelId, setActiveChannelId] = useState<string>("development");
  const [messagesByChannel, setMessagesByChannel] = useState<Record<string, Message[]>>(INITIAL_MESSAGES);

  // Modal state for adding a channel
  const [showAddChannelModal, setShowAddChannelModal] = useState(false);
  const [newChannelName, setNewChannelName] = useState("");
  const [newChannelDesc, setNewChannelDesc] = useState("");

  const activeWorkspace = workspaces.find((w) => w.id === activeWorkspaceId) || workspaces[0];
  const activeChannel = activeWorkspace.channels.find((c) => c.id === activeChannelId) || activeWorkspace.channels[0];
  const activeMessages = messagesByChannel[activeChannel?.id] || [];

  const handleLoginSuccess = (userName: string) => {
    setCurrentUser(userName);
    setIsAuthenticated(true);
  };

  const handleSelectWorkspace = (workspaceId: string) => {
    setActiveWorkspaceId(workspaceId);
    const targetWorkspace = workspaces.find((w) => w.id === workspaceId);
    if (targetWorkspace && targetWorkspace.channels.length > 0) {
      setActiveChannelId(targetWorkspace.channels[0].id);
    }
  };

  const handleSendMessage = (text: string) => {
    if (!activeChannel) return;
    const newMessage: Message = {
      id: Date.now().toString(),
      sender: { id: "current-user", name: currentUser, avatar: currentUser.charAt(0).toUpperCase(), status: "online" },
      text,
      time: new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }),
      reactions: [],
    };

    setMessagesByChannel((prev) => ({
      ...prev,
      [activeChannel.id]: [...(prev[activeChannel.id] || []), newMessage],
    }));
  };

  const handleToggleReaction = (messageId: string, emoji: string) => {
    if (!activeChannel) return;
    setMessagesByChannel((prev) => {
      const channelMsgs = prev[activeChannel.id] || [];
      const updatedMsgs = channelMsgs.map((msg) => {
        if (msg.id !== messageId) return msg;
        const exists = msg.reactions.includes(emoji);
        const reactions = exists
          ? msg.reactions.filter((r) => r !== emoji)
          : [...msg.reactions, emoji];
        return { ...msg, reactions };
      });
      return { ...prev, [activeChannel.id]: updatedMsgs };
    });
  };

  const handleCreateChannel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChannelName.trim()) return;

    const formattedName = newChannelName.trim().charAt(0).toUpperCase() + newChannelName.trim().slice(1);
    const newChanId = `${activeWorkspaceId}-${Date.now()}`;

    const newChan: Channel = {
      id: newChanId,
      name: formattedName,
      description: newChannelDesc.trim() || `${formattedName} channel`,
      memberCount: 1,
    };

    setWorkspaces((prev) =>
      prev.map((ws) =>
        ws.id === activeWorkspaceId
          ? { ...ws, channels: [...ws.channels, newChan] }
          : ws
      )
    );

    setActiveChannelId(newChanId);
    setNewChannelName("");
    setNewChannelDesc("");
    setShowAddChannelModal(false);
  };

  // If not authenticated, render the glassmorphism Auth Landing Page
  if (!isAuthenticated) {
    return <AuthLanding onLoginSuccess={handleLoginSuccess} />;
  }

  // Render Main Workspace Application
  return (
    <div className="app">
      <Sidebar
        workspaces={workspaces}
        activeWorkspaceId={activeWorkspaceId}
        onSelectWorkspace={handleSelectWorkspace}
        channels={activeWorkspace.channels}
        activeChannelId={activeChannel?.id}
        onSelectChannel={setActiveChannelId}
        onOpenAddChannel={() => setShowAddChannelModal(true)}
      />

      {activeChannel && (
        <ChatArea
          channel={activeChannel}
          messages={activeMessages}
          onSendMessage={handleSendMessage}
          onToggleReaction={handleToggleReaction}
        />
      )}

      {/* Add Channel Modal */}
      {showAddChannelModal && (
        <div className="modal-overlay" onClick={() => setShowAddChannelModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Create a channel in {activeWorkspace.name}</h2>
              <button onClick={() => setShowAddChannelModal(false)}>✕</button>
            </div>
            <form onSubmit={handleCreateChannel}>
              <div className="form-group">
                <label>Channel Name</label>
                <input
                  type="text"
                  placeholder="e.g. Frontend-Dev"
                  value={newChannelName}
                  onChange={(e) => setNewChannelName(e.target.value)}
                  autoFocus
                  required
                />
              </div>
              <div className="form-group">
                <label>Description (optional)</label>
                <input
                  type="text"
                  placeholder="What is this channel about?"
                  value={newChannelDesc}
                  onChange={(e) => setNewChannelDesc(e.target.value)}
                />
              </div>
              <div className="modal-actions">
                <button
                  type="button"
                  className="cancel-btn"
                  onClick={() => setShowAddChannelModal(false)}
                >
                  Cancel
                </button>
                <button type="submit" className="create-btn">
                  Create Channel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;