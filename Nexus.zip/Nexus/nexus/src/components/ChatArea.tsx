import { useState, useRef, useEffect } from "react";
import type { Message, Channel, Member } from "../types";

interface ChatAreaProps {
  channel: Channel;
  messages: Message[];
  onSendMessage: (text: string) => void;
  onToggleReaction: (messageId: string, emoji: string) => void;
  onClearChat?: (channelId: string) => void;
}


const CHANNEL_MEMBERS: Record<string, Member[]> = {
  development: [
    { id: "1", name: "Alexander", avatar: "A", role: "Frontend Lead", status: "online" },
    { id: "2", name: "Sarah", avatar: "S", role: "Product Manager", status: "online" },
    { id: "3", name: "David", avatar: "D", role: "Backend Dev", status: "away" },
    { id: "4", name: "Elena", avatar: "E", role: "UI Designer", status: "offline" },
  ],
  general: [
    { id: "1", name: "Alexander", avatar: "A", role: "Frontend Lead", status: "online" },
    { id: "2", name: "Sarah", avatar: "S", role: "Product Manager", status: "online" },
  ],
};

function ChatArea({
  channel,
  messages,
  onSendMessage,
  onToggleReaction,
  onClearChat,
}: ChatAreaProps) {
  const [messageText, setMessageText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [showMembers, setShowMembers] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // auto scroll stuff
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (!isSearching) {
      scrollToBottom();
    }
  }, [messages, channel.id, isSearching]);

  const handleSend = () => {
    if (messageText.trim() === "") return;
    onSendMessage(messageText);
    setMessageText("");
  };

  
  const filteredMessages = messages.filter((msg) =>
    msg.text.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentMembers = CHANNEL_MEMBERS[channel.id] || CHANNEL_MEMBERS.general;

  return (
    <div className="chat-layout-wrapper">
      <main className="chat-area">
        {/* Chat Header */}
        <header className="chat-header">
          <div>
            <div className="channel-name">
              <span>*</span>
              <h2>{channel.name}</h2>
              {isMuted && <span className="muted-badge">🔕 Muted</span>}
            </div>
            <p>{channel.description}</p>
          </div>

          <div className="chat-actions">
            {/* Search Toggle */}
            <button
              title="Search"
              className={isSearching ? "active-action" : ""}
              onClick={() => {
                setIsSearching(!isSearching);
                if (isSearching) setSearchQuery("");
              }}
            >
              ⌕
            </button>

            {/* Members Drawer Toggle */}
            <button
              title="Members"
              className={showMembers ? "active-action" : ""}
              onClick={() => setShowMembers(!showMembers)}
            >
              ♙
            </button>

            {/* More Menu Toggle */}
            <div className="dropdown-container">
              <button
                title="More"
                className={showMenu ? "active-action" : ""}
                onClick={() => setShowMenu(!showMenu)}
              >
                •••
              </button>

              {/* More Actions Dropdown Menu */}
              {showMenu && (
                <div className="dropdown-menu">
                  <button
                    onClick={() => {
                      setIsMuted(!isMuted);
                      setShowMenu(false);
                    }}
                  >
                    {isMuted ? "🔔 Unmute Channel" : "🔕 Mute Channel"}
                  </button>
                  <button
                    onClick={() => {
                      if (onClearChat) onClearChat(channel.id);
                      setShowMenu(false);
                    }}
                  >
                    🗑️ Clear Messages
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Search Input Bar (conditionally shown) */}
        {isSearching && (
          <div className="search-bar">
            <input
              type="text"
              placeholder={`Search messages in #${channel.name}...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus
            />
            {searchQuery && (
              <span className="search-results-count">
                {filteredMessages.length} found
              </span>
            )}
            <button
              className="close-search"
              onClick={() => {
                setIsSearching(false);
                setSearchQuery("");
              }}
            >
              ✕
            </button>
          </div>
        )}

        {/* Messages List */}
        <section className="messages">
          {filteredMessages.length === 0 ? (
            <div className="empty-messages">
              {isSearching ? "No messages found matching your search." : "No messages here yet."}
            </div>
          ) : (
            filteredMessages.map((message) => (
              <article className="message" key={message.id}>
                <div className="message-avatar">{message.sender.avatar}</div>

                <div className="message-content">
                  <div className="message-meta">
                    <strong>{message.sender.name}</strong>
                    <span>{message.time}</span>
                  </div>

                  <p>{message.text}</p>

                  <div className="message-reactions">
                    {["👍", "❤️", "🔥", "🚀"].map((emoji) => {
                      const isActive = message.reactions.includes(emoji);
                      return (
                        <button
                          key={emoji}
                          className={`reaction-button ${isActive ? "active" : ""}`}
                          onClick={() => onToggleReaction(message.id, emoji)}
                        >
                          {emoji}
                        </button>
                      );
                    })}

                    {message.reactions.length > 0 && (
                      <span className="reaction-count">
                        {message.reactions.join(" ")}
                      </span>
                    )}
                  </div>
                </div>
              </article>
            ))
          )}

          <div ref={messagesEndRef} />
        </section>

        {/* Message Input */}
        <div className="message-input-wrapper">
          <button className="attachment-button">+</button>

          <input
            type="text"
            placeholder={`Message #${channel.name}...`}
            value={messageText}
            onChange={(event) => setMessageText(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") handleSend();
            }}
          />

          <button className="send-button" onClick={handleSend}>
            ➤
          </button>
        </div>
      </main>

      {/* Slide-out Members Panel */}
      {showMembers && (
        <aside className="members-panel">
          <div className="members-header">
            <h3>Members ({currentMembers.length})</h3>
            <button onClick={() => setShowMembers(false)}>✕</button>
          </div>

          <div className="members-list">
            {currentMembers.map((member) => (
              <div key={member.id} className="member-item">
                <div className="member-avatar">
                  {member.avatar}
                  <span className={`status-dot ${member.status}`}></span>
                </div>
                <div className="member-info">
                  <strong>{member.name}</strong>
                  <span>{member.role}</span>
                </div>
              </div>
            ))}
          </div>
        </aside>
      )}
    </div>
  );
}

export default ChatArea;