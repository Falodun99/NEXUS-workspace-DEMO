import type { Workspace, Channel } from "../types";

interface SidebarProps {
  workspaces: Workspace[];
  activeWorkspaceId: string;
  onSelectWorkspace: (id: string) => void;
  channels: Channel[];
  activeChannelId: string;
  onSelectChannel: (id: string) => void;
  onOpenAddChannel: () => void;
}

function Sidebar({
  workspaces,
  activeWorkspaceId,
  onSelectWorkspace,
  channels,
  activeChannelId,
  onSelectChannel,
  onOpenAddChannel,
}: SidebarProps) {
  const activeWorkspace = workspaces.find((w) => w.id === activeWorkspaceId);

  return (
    <aside className="sidebar">
      {/* Brand */}
      <div className="brand">
        <div className="brand-logo">
          {activeWorkspace ? activeWorkspace.icon : "N"}
        </div>
        <div>
          <h1>{activeWorkspace ? activeWorkspace.name.toUpperCase() : "NEXUS"}</h1>
          <span>Workspace</span>
        </div>
      </div>

      {/* Workspaces */}
      <div className="sidebar-section">
        <div className="section-title">
          <span>WORKSPACES</span>
        </div>

        <div className="workspace-list">
          {workspaces.map((ws) => (
            <div
              key={ws.id}
              className={`workspace-item ${activeWorkspaceId === ws.id ? "active" : ""}`}
              onClick={() => onSelectWorkspace(ws.id)}
            >
              <div className={`workspace-icon ${ws.colorClass}`}>{ws.icon}</div>
              <span>{ws.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Channels */}
      <div className="sidebar-section">
        <div className="section-title">
          <span>CHANNELS</span>
          <button onClick={onOpenAddChannel} title="Add Channel">+</button>
        </div>

        <div className="channel-list">
          {channels.map((channel) => (
            <div
              key={channel.id}
              className={`channel-item ${
                activeChannelId === channel.id ? "active-channel" : ""
              }`}
              onClick={() => onSelectChannel(channel.id)}
            >
              <span>*</span>
              <span>{channel.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* User */}
      <div className="user-profile">
        <div className="avatar">
          A
          <span className="online-dot"></span>
        </div>

        <div className="user-info">
          <strong>Alexander</strong>
          <span>Online</span>
        </div>

        <button className="more-button">•••</button>
      </div>
    </aside>
  );
}

export default Sidebar;