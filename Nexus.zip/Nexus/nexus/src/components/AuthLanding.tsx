import React, { useState } from "react";

interface AuthLandingProps {
  onLoginSuccess: (userName: string) => void;
}

export default function AuthLanding({ onLoginSuccess }: AuthLandingProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    if (!isLogin && !name) return;

    const displayName = isLogin
      ? email.split("@")[0] || "Alexander"
      : name || "Alexander";

    onLoginSuccess(displayName);
  };

  return (
    <div className="auth-container">
      {/* Simple GIF Background */}
      <div className="auth-bg-gif"></div>
      
      {/* Glassmorphism Dark Overlay */}
      <div className="auth-overlay"></div>

      {/* Glassmorphism Card */}
      <div className="auth-card">
        <div className="auth-brand">
          <div className="auth-logo">N</div>
          <h1>NEXUS</h1>
        </div>

        <p className="auth-subtitle">
          {isLogin
            ? "Sign in to access your workspace"
            : "Create your account to start collaborating"}
        </p>

        <div className="auth-tabs">
          <button
            type="button"
            className={isLogin ? "active" : ""}
            onClick={() => setIsLogin(true)}
          >
            Login
          </button>
          <button
            type="button"
            className={!isLogin ? "active" : ""}
            onClick={() => setIsLogin(false)}
          >
            Register
          </button>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          {!isLogin && (
            <div className="auth-field">
              <label>Full Name</label>
              <input
                type="text"
                placeholder="e.g. Ayodele Alexander"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required={!isLogin}
              />
            </div>
          )}

          <div className="auth-field">
            <label>Email Address</label>
            <input
              type="email"
              placeholder="ayodelestuffs@gmail.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="auth-field">
            <label>Password</label>
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="auth-submit-btn">
            {isLogin ? "Enter Workspace" : "Create Account"}
          </button>
        </form>

        <div className="auth-footer">
          {isLogin ? (
            <span>
              Don't have an account?{" "}
              <button onClick={() => setIsLogin(false)}>Sign Up</button>
            </span>
          ) : (
            <span>
              Already have an account?{" "}
              <button onClick={() => setIsLogin(true)}>Log In</button>
            </span>
          )}
        </div>
      </div>
    </div>
  );
}