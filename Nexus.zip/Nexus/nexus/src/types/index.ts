export interface User {
  id: string;
  name: string;
  avatar: string;
  status: "online" | "offline" | "away";
}

export interface Message {
  id: string;
  sender: User;
  text: string;
  time: string;
  reactions: string[];
}

export interface Channel {
  id: string;
  name: string;
  description: string;
  memberCount: number;
}

export interface Member {
  id: string;
  name: string;
  avatar: string;
  role: string;
  status: "online" | "offline" | "away";
}

export interface Workspace {
  id: string;
  name: string;
  icon: string;
  colorClass: string;
  channels: Channel[];
}